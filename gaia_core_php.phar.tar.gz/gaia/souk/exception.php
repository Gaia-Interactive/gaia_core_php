<?php
namespace Gaia\Souk; class Exception extends \Gaia\Exception { } 