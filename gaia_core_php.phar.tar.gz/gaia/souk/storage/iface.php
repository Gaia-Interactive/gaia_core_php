<?php
namespace Gaia\Souk\Storage; interface Iface { } 