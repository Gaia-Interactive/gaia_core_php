<?php
namespace Gaia\Souk; interface StockpileBinder_Iface { public function itemAccount( $user_id ); public function currencyAccount( $user_id ); public function currencyId(); } 