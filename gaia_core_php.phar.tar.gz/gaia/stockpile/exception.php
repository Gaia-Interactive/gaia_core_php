<?php
namespace Gaia\Stockpile; class Exception extends \Gaia\Exception { } 