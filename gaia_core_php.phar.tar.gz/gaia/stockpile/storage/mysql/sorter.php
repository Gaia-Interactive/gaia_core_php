<?php
namespace Gaia\Stockpile\Storage\MySQL; use \Gaia\Stockpile\Exception; class Sorter extends Core { const TABLE = 'sort'; const SQL_CREATE = "CREATE TABLE IF NOT EXISTS `{TABLE}` (
  `user_id` bigint unsigned NOT NULL,
  `item_id` int unsigned NOT NULL,
  `pos` bigint unsigned NOT NULL default '0',
  UNIQUE KEY  (`user_id`,`item_id`),
  KEY `user_id_pos` ( `user_id`, `pos`)
) ENGINE=InnoDB"; const SQL_SELECT = 'SELECT `item_id`, `pos` FROM `{TABLE}` WHERE `user_id` = %i AND `item_id` IN ( %i )'; const SQL_INSERT = 'INSERT INTO `{TABLE}` (`user_id`, `item_id`, `pos`) VALUES 
 %s
ON DUPLICATE KEY UPDATE `pos` = VALUES(`pos`)'; const SQL_INSERT_IGNORE = 'INSERT IGNORE INTO `{TABLE}` (`user_id`, `item_id`, `pos`) VALUES 
 %s'; const SQL_REMOVE = 'UPDATE `{TABLE}` SET `pos` = 0 WHERE `user_id` = %i AND `item_id` = %i'; const SQL_MAXPOS = 'SELECT MAX(`pos`) as `pos` FROM `{TABLE}` WHERE `user_id` = %i'; public function sort( $pos, array $item_ids, $ignore_dupes = FALSE ){ $batch = array(); foreach( $item_ids as $item_id ){ $pos = bcadd($pos, 1); $batch[] = $this->db->prep('(%i, %i, %i)', $this->user_id, $item_id, $pos ); } $rs = $this->execute(sprintf( $this->sql( $ignore_dupes ? 'INSERT_IGNORE' : 'INSERT'), implode(",\n ", $batch ))); return $rs->affected(); } public function remove( $item_id ){ $rs = $this->execute( $this->sql('REMOVE'), $this->user_id, $item_id ); } public function fetchPos( array $ids ){ $rs = $this->db->execute($this->sql('SELECT'), $this->user_id, $ids ); $list = array(); while( $row = $rs->fetch() ){ $list[ $row['item_id'] ] = $row['pos']; } $rs->free(); return $list; } public function maxPos(){ $rs = $this->execute($this->sql('MAXPOS'), $this->user_id ); $row = $rs->fetch(); $rs->free(); return $row['pos']; } } 