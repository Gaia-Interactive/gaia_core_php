<?php
namespace Gaia\Stockpile\Storage; interface Iface { } 