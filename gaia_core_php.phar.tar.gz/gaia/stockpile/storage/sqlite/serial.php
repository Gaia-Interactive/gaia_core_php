<?php
namespace Gaia\Stockpile\Storage\SQLite; use \Gaia\Stockpile\Exception; use \Gaia\DB\Transaction; class Serial extends Core { const TABLE = 'serial'; const SQL_CREATE = "CREATE TABLE IF NOT EXISTS `{TABLE}` (
  `user_id` BIGINT NOT NULL,
  `item_id` INTEGER NOT NULL,
  `serial` BIGINT NOT NULL,
  `properties` TEXT,
  `soft_delete` INTEGER NOT NULL DEFAULT '0',
  UNIQUE (`user_id`,`item_id`,`serial`)
  )"; const SQL_INDEX = "CREATE INDEX IF NOT EXISTS `{TABLE}_idx_user_id_soft_delete_item_id` ON `{TABLE}` (`user_id`, `soft_delete`, `item_id`)"; const SQL_ADD = "INSERT OR IGNORE INTO `{TABLE}` (`user_id`, `item_id`, `serial`, `properties`, `soft_delete`) VALUES (%i, %i, %i, %s, 0)"; const SQL_UPDATE = 'UPDATE `{TABLE}` SET `properties` = %s, `soft_delete` = 0 WHERE 
`user_id` = %i AND `item_id` = %i AND `serial` = %i'; const SQL_SUBTRACT = 'UPDATE {TABLE} SET `soft_delete` = 1 WHERE 
`user_id` = %i AND 
item_id = %i AND 
`serial` IN (%i) AND 
`soft_delete` = 0'; const SQL_FETCH = 'SELECT `item_id`, `serial`, `properties` FROM `{TABLE}` 
 WHERE `user_id` = %i AND `soft_delete` = 0'; const SQL_FETCH_ITEM = 'SELECT `item_id`, `serial`, `properties` FROM `{TABLE}` 
 WHERE `user_id` = %i AND `soft_delete` = 0 AND `item_id` IN( %i )'; const SQL_VERIFY = 'SELECT `serial` FROM `{TABLE}` 
WHERE `user_id` = %i AND `item_id` = %i AND `serial` IN ( %i )'; public function add( $item_id, $quantity ){ $batches = array(); $local_txn = $this->claimStart(); foreach( $quantity->all() as $serial => $properties ){ $properties = json_encode( $properties ); $rs = $this->execute($this->sql('ADD'), $this->user_id, $item_id, $serial, $properties); if( $rs->affected() < 1 ) { $rs = $this->execute($this->sql('UPDATE'), $properties, $this->user_id, $item_id, $serial); if( $rs->affected() < 1 ) { if( $local_txn ) Transaction::rollback(); throw new Exception('database error', $this->dbInfo() ); } } } if( $local_txn ) { if( ! Transaction::commit()) throw new Exception('database error', $this->dbInfo() ); } return TRUE; } public function subtract( $item_id, $serials ){ $rs = $this->execute( $this->sql('SUBTRACT'), $this->user_id, $item_id, $serials ); return $rs->affected(); } public function fetch( array $item_ids = NULL ){ if( is_array( $item_ids ) ) { $rs = $this->execute( $this->sql('FETCH_ITEM'), $this->user_id, $item_ids ); } else { $rs = $this->execute( $this->sql('FETCH'), $this->user_id ); } $list = array(); while( $row = $rs->fetch() ){ if( ! isset( $list[ $row['item_id'] ] ) ) $list[ $row['item_id'] ] = array(); $list[ $row['item_id'] ][ $row['serial'] ] = $this->deserializeProperties( $row['properties'] ); } $rs->free(); return $list; } public function verifySerials( $item_id, array $serials ){ $rs = $this->execute( $this->sql('VERIFY'), $this->user_id, $item_id, $serials ); $serials = array(); while( $row = $rs->fetch() ) $serials[] = $row['serial']; $rs->free(); return $serials; } protected function deserializeProperties( $v ){ if (strlen( $v ) < 0 ) return array(); $v = @json_decode( $v, TRUE ); if( ! is_array( $v ) ) return array(); return $v; } } 