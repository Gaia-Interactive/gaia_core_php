<?php
namespace Gaia\Cache; class Memcache extends \Gaia\Store\Memcache { } 