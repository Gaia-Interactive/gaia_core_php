<?php
namespace Gaia\Cache; class Tier extends \Gaia\Store\Tier { } 