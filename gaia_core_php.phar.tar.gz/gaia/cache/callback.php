<?php
namespace Gaia\Cache; class Callback extends \Gaia\Store\Callback { } 