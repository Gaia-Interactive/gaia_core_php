<?php
namespace Gaia\Cache; class Session extends \Gaia\Store\Session { } 