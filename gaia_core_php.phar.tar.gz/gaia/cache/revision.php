<?php
namespace Gaia\Cache; class Revision extends \Gaia\Store\Revision { } 