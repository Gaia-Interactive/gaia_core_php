<?php
namespace Gaia\Cache; class Options extends \Gaia\Store\Options { } 