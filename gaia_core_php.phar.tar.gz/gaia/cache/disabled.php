<?php
namespace Gaia\Cache; class Disabled extends \Gaia\Store\Disabled { } 