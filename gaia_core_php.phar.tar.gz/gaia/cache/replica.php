<?php
namespace Gaia\Cache; class Replica extends \Gaia\Store\Replica { } 