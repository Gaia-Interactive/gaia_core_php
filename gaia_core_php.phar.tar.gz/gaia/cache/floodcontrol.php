<?php
namespace Gaia\Cache; class FloodControl extends \Gaia\Store\FloodControl{ } 