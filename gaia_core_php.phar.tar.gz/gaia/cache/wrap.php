<?php
namespace Gaia\Cache; class Wrap extends \Gaia\Store\Wrap { } 