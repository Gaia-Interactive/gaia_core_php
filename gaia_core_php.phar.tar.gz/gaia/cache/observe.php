<?php
namespace Gaia\Cache; class Observe extends \Gaia\Store\Observe { } 