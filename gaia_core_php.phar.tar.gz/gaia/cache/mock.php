<?php
namespace Gaia\Cache; class Mock extends \Gaia\Store\Mock { } 