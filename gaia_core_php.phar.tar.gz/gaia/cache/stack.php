<?php
namespace Gaia\Cache; class Stack extends \Gaia\Store\Stack { } 