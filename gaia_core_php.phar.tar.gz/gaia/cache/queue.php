<?php
namespace Gaia\Cache; class Queue extends \Gaia\Store\Queue { } 