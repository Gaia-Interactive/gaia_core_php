<?php
namespace Gaia\Cache; class APC extends \Gaia\Store\APC{ } 