<?php
namespace Gaia\Cache; class Prefix extends \Gaia\Store\Prefix { } 