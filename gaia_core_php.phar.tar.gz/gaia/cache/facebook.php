<?php
namespace Gaia\Cache; class Facebook extends \Gaia\Facebook\ApiCache { } 