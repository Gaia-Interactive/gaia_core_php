<?php
namespace Gaia\Cache; class Redis extends \Gaia\Store\Redis { } 