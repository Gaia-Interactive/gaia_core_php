<?php
namespace Gaia\Cache; class Gate extends \Gaia\Store\Gate { } 