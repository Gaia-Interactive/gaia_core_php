<?php
namespace Gaia\NewID; Interface Iface { public function id(); public function ids( $ct = 1 ); }